// Class Declarations
#include <iostream>
#include <string>

// Header Files
#include "Plane.h"

using namespace std;

// Default Constructor with Default values
Plane::Plane()
{
	Plane_ID = 0;
	Make = "No Make";
	Model = "No Model";
	Tail_Number = "No Tail Number";
	Seats = 0;
	Range = 0;
	Status = 0;
}

// Overloaded Constructor
Plane::Plane(int Plane_ID, string Make, string Model, string Tail_Number, int Seats, int Range, int Status)
{
	this -> Plane_ID = Plane_ID;
	this -> Make = Make;
	this -> Model = Model;
	this -> Tail_Number = Tail_Number;
	this -> Seats = Seats;
	this -> Range = Range;
	this -> Status = Status;
}	
	
//Setters
void Plane::Set_Plane_ID(int Plane_ID)
{
	this -> Plane_ID = Plane_ID;
}
void Plane::Set_Make(string Make)
{
	this -> Make = Make;
}
void Plane::Set_Model(string Model)
{
	this -> Model = Model;
}
void Plane::Set_Tail_Number(string Tail_Number)
{
	this -> Tail_Number = Tail_Number;
}
void Plane::Set_Seats(int Seats)
{
	this -> Seats = Seats;
}
void Plane::Set_Range(int Range)
{
	this -> Range = Range;
}
void Plane::Set_Status(int Status)
{
	this -> Status = Status;
}
		
// Getters
int Plane::Get_Plane_ID() const
{
	return Plane_ID;
}
string Plane::Get_Make() const
{
	return Make;
}
string Plane::Get_Model() const
{
	return Model;
}
string Plane::Get_Tail_Number() const
{
	return Tail_Number;
}
int Plane::Get_Seats() const
{
	return Seats;
}
int Plane::Get_Range() const
{
	return Range;
}
string Plane::Get_Status() const
{
	string Status_Of_Plane;
	if(Status == 1)
	{
		Status_Of_Plane = "OUT (In Flight)";
	}
	else if(Status == 2)
	{
		Status_Of_Plane = "IN (Available)";		
	}
	else if(Status == 3)
	{
		Status_Of_Plane = "REPAIR (Out for Repair)";
	}

	return Status_Of_Plane;
	
}