// Class Declarations
#include <iostream>
#include <string>

// Header Files
#include "Flights.h"

using namespace std;

// Default Constructor with Default values
Flights::Flights()
{
    Flight_ID = 0;
    Plane_ID = 0;
    Pilot_ID = 0;
    CoPilot_ID = 0;
    Crew_ID_1 = 0;
    Crew_ID_2 = 0;
    Crew_ID_3 = 0;
    Flight_Start_Date = "No Flight Start Date";
    Flight_End_Date = "No Flight End Date";
    Time = "No Time";
    Starting_Airport_Code = "No Starting Airport Code";
    Ending_Airport_Code = "No Ending Airport Code";
    Num_Of_Passengers = 0;
    Flight_Status = 0;    
}

// Overloaded Constructor
Flights::Flights(int Flight_ID, int Plane_ID, int Pilot_ID, int CoPilot_ID, int Crew_ID_1, int Crew_ID_2, int Crew_ID_3, string Flight_Start_Date, 
                string Flight_End_Date, string Time, string Starting_Airport_Code, string Ending_Airport_Code, int Num_Of_Passengers, int Flight_Status)
{
    this -> Flight_ID = Flight_ID;
    this -> Plane_ID = Plane_ID;
    this -> Pilot_ID = Pilot_ID;
    this -> CoPilot_ID = CoPilot_ID;
    this -> Crew_ID_1 = Crew_ID_1;
    this -> Crew_ID_2 = Crew_ID_2;
    this -> Crew_ID_3 = Crew_ID_3;
    this -> Flight_Start_Date = Flight_Start_Date;
    this -> Flight_End_Date = Flight_End_Date;
    this -> Time = Time;
    this -> Starting_Airport_Code = Starting_Airport_Code;
    this -> Ending_Airport_Code = Ending_Airport_Code;
    this -> Num_Of_Passengers = Num_Of_Passengers;
    this -> Flight_Status = Flight_Status;    
}

//Setters
void Flights::Set_Flight_ID(int Flight_ID)
{
    this -> Flight_ID = Flight_ID;
}
void Flights::Set_Plane_ID(int Plane_ID)
{
    this -> Plane_ID = Plane_ID;
}
void Flights::Set_Pilot_ID(int Pilot_ID)
{
    this -> Pilot_ID = Pilot_ID;
}
void Flights::Set_CoPilot_ID(int CoPilot_ID)
{
    this -> CoPilot_ID = CoPilot_ID;
}
void Flights::Set_Crew_ID_1(int Crew_ID_1)
{
    this -> Crew_ID_1 = Crew_ID_1;
}
void Flights::Set_Crew_ID_2(int Crew_ID_2)
{
    this -> Crew_ID_2 = Crew_ID_2;
}
void Flights::Set_Crew_ID_3(int Crew_ID_3)
{
    this -> Crew_ID_3 = Crew_ID_3;
}
void Flights::Set_Flight_Start_Date(string Flight_Start_Date)
{
    this -> Flight_Start_Date = Flight_Start_Date;
}
void Flights::Set_Flight_End_Date(string Flight_End_Date)
{
    this -> Flight_End_Date = Flight_End_Date;
}
void Flights::Set_Time(string Time)
{
    this -> Time = Time;
}
void Flights::Set_Starting_Airport_Code(string Starting_Airport_Code)
{
    this -> Starting_Airport_Code = Starting_Airport_Code;
}
void Flights::Set_Ending_Airport_Code(string Ending_Airport_Code)
{
    this -> Ending_Airport_Code = Ending_Airport_Code;
}
void Flights::Set_Num_Of_Passengers(int Num_Of_Passengers)
{
    this -> Num_Of_Passengers = Num_Of_Passengers;
}
void Flights::Set_Flight_Status(int Flight_Status)
{
    this -> Flight_Status = Flight_Status;
}  


//Setters
int Flights::Get_Flight_ID() const
{
    return Flight_ID;
}
int Flights::Get_Plane_ID() const
{
    return Plane_ID;
}
int Flights::Get_Pilot_ID() const
{
    return Pilot_ID;
}
int Flights::Get_CoPilot_ID() const
{
    return CoPilot_ID;
}
int Flights::Get_Crew_ID_1() const
{
    return Crew_ID_1;
}
int Flights::Get_Crew_ID_2() const
{
    return Crew_ID_2;
}
int Flights::Get_Crew_ID_3() const
{
    return Crew_ID_3;
}
string Flights::Get_Flight_Start_Date() const
{
    return Flight_Start_Date;
}
string Flights::Get_Flight_End_Date() const
{
    return Flight_End_Date;
}
string Flights::Get_Time() const
{
    return Time;
}
string Flights::Get_Starting_Airport_Code() const
{
    return Starting_Airport_Code;
}
string Flights::Get_Ending_Airport_Code() const
{
    return Ending_Airport_Code;
}
int Flights::Get_Num_Of_Passengers() const
{
    return Num_Of_Passengers;
}
string Flights::Get_Flight_Status() const
{
    string Status;

	if(Flight_Status == 1)
	{
		Status = "Available";
	}
	else if(Flight_Status == 2)
	{
		Status = "Cancelled";		
	}
	else if(Flight_Status == 3)
	{
		Status = "Completed";
	}

	return Status;
}