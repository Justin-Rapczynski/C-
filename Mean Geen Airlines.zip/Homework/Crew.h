#ifndef CREW_H
#define CREW_H

// Class Declarations
#include <string>

using namespace std;

// Class Flights, with private variables and public functions
class Crew
{
    private:
        string Name;
        int ID_Number;
        int Type;
        int Status;

    public:
        Crew();
        Crew(string Name, int ID_Number, int Type, int Status);

        //Setters
        void Set_Name(string Name);
        void Set_ID_Number(int ID_Number);
        void Set_Type(int Type);
        void Set_Status(int Status);

        //Getters
        string Get_Name() const;
        int Get_ID_Number() const;
        string Get_Type() const;
        string Get_Status() const;

};

#endif