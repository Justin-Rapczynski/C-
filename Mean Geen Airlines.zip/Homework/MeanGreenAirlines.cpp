/*

Juan Alberto Ruiz
JuanRuiz3@my.unt.edu
CSCE 1040
04/09/18

This program is in the initial stages of becoming a full integrated
Airlines Scheduler. The program is capable of adding unlimited crew members
and unlimited planes as well as flights using vectors, maps and lists.
Crew can be added, planes can be added and flights mixes the two together in 
order to create a flight. The program is capable of writing the information to
a file as well as being a smart program that knows and traks which is plane 
is where and with which crew.
*/

// Header Files
#include <iostream>
#include "Plane_Collections.h"
#include "Crew_Collections.h"
#include "Flights_Collections.h"

using namespace std;

int main()
{
	//Declaration of functions. So we can use them in the Switch
	Plane_Collections Plane_Collect;
	Crew_Collections Crew_Collect;
	Flights_Collections Flight;

	Plane Plane_Info;
	Crew Crew_Info;
	
	
	
	int Main_Menu;
	
	// Do While for Main Menu
	do 
	{
		// MAIN MENU, THE MENU HAS MANY LEVELS WITH MANY OPTIONS.
		cout << "=========================================================================================================" << endl;
		cout << endl << "---------- MAIN MENU ----------" << endl;
		cout << "1) Manage Plane" << endl;
		cout << "2) Manage Crew" << endl;
		cout << "3) Manage Flights" << endl;
		cout << "4) Quit" << endl << endl;

		cout << ">> "; 
		cin >> Main_Menu;
		
		switch(Main_Menu)
		{
			
			case 1:
			{
				int Option;
				
				system("@cls||clear");
				cout << "=========================================================================================================" << endl;
				cout << endl << "1) Add Plane" << endl;
				cout << "2) Edit Plane" << endl;
				cout << "3) Delete Plane" << endl;
				cout << "4) Search Plane" << endl;
				cout << "5) Print Planes" << endl;
				cout << "6) <- GO BACK" << endl << endl;

				cout << ">> ";
				cin >> Option;

				if(Option == 1)
				{
					Plane_Collect.Add();
				}
				
				else if(Option == 2)
				{
					Plane_Collect.Edit();
				}
				
				else if(Option == 3)
				{
					int Delete_Plane;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Delete Plane" << endl;
					cout << "2) Delete ALL Planes" << endl << endl;
					cout << "3) <- GO BACK" << endl;

					cout << ">> ";
					cin >> Delete_Plane;

					if(Delete_Plane == 1)
					{
						Plane_Collect.Delete();
					}
					else if(Delete_Plane == 2)
					{
						Plane_Collect.Delete_All();
					}
					else if(Delete_Plane == 3)
					{
						break;
					}


				}
				
				else if(Option == 4)
				{
					
					
				}
				
				else if(Option == 5)
				{
					int Print_Planes;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Print ALL Planes" << endl;
					cout << "2) Print Single Plane" << endl;
					cout << "3) <- GO BACK" << endl << endl;

					cout << ">> ";
					cin >> Print_Planes;

					if(Print_Planes == 1)
					{
						Plane_Collect.Print_List();
					}
					else if(Print_Planes == 2)
					{
						Plane_Collect.Print_Single();
					}
					else if(Print_Planes == 3)
					{
						break;
					}

				}

				else if(Option == 6)
				{
					break;
				}
				
				break;

			}	// END MANAGE PLANE

			case 2:
			{
				int Option;
				
				system("@cls||clear");
				cout << "=========================================================================================================" << endl;
				cout << endl << "1) Add Crew" << endl;
				cout << "2) Edit Crew" << endl;
				cout << "3) Delete Crew" << endl;
				cout << "4) Search Crew" << endl;
				cout << "5) Print Crew" << endl;
				cout << "6) <- GO BACK" << endl << endl;

				cout << ">> ";
				cin >> Option;

				if(Option == 1)
				{
					Crew_Collect.Add();
				}
				
				else if(Option == 2)
				{
					Crew_Collect.Edit();
				}
				
				else if(Option == 3)
				{
					int Delete_Crew;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Delete Crew" << endl;
					cout << "2) Delete ALL Crew" << endl;
					cout << "3) <- GO BACK" << endl << endl;

					cout << ">> ";
					cin >> Delete_Crew;

					if(Delete_Crew == 1)
					{
						Crew_Collect.Delete();
					}
					else if(Delete_Crew == 2)
					{
						Crew_Collect.Delete_All();
					}
					else if(Delete_Crew == 3)
					{
						break;
					}
				

				}
				
				else if(Option == 4)
				{
					
				}
				
				else if(Option == 5)
				{
					int Print_Crew;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Print ALL Employee's" << endl;
					cout << "2) Print Single Employee" << endl;
					cout << "3) <- GO BACK" << endl << endl;

					cout << ">> ";
					cin >> Print_Crew;

					if(Print_Crew == 1)
					{
						Crew_Collect.Print_List();
					}
					else if(Print_Crew == 2)
					{
						Crew_Collect.Print_Single();
					}
					else if(Print_Crew == 3)
					{
						break;
					}

				}

				else if(Option == 6)
				{
					break;
				}
				
				break;
				
			}	// END MANAGE CREW

			case 3:
			{	
				int Option;

				system("@cls||clear");
				cout << "=========================================================================================================" << endl;
				cout << endl << "1) Add Flights" << endl;
				cout << "2) Edit Flights" << endl;
				cout << "3) Delete FLights" << endl;
				cout << "4) Search Flights" << endl;
				cout << "5) Print Flights" << endl;
				cout << "6) <- GO BACK" << endl << endl;

				cout << ">> ";
				cin >> Option;
				
				if(Option == 1)
				{
					Flight.Add(&Plane_Collect, &Crew_Collect, &Plane_Info, &Crew_Info);
				}	// Adding Flights

				else if(Option == 2)
				{
					Flight.Edit(&Plane_Collect, &Crew_Collect, &Plane_Info, &Crew_Info);
				}	// Edit Flights

				else if(Option == 3)
				{
					int Delete_Flights;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Delete Flight" << endl;
					cout << "2) Delete ALL Flight" << endl;
					cout << "3) <- GO BACK" << endl << endl;

					cout << ">> ";
					cin >> Delete_Flights;

					if(Delete_Flights == 1)
					{
						Flight.Delete();
					}

					else if(Delete_Flights == 2)
					{
						Flight.Delete_All();
					}

					else if(Delete_Flights == 3)
					{
						break;
					}
					
				}	// Delete Flights

				else if(Option == 4)
				{

				}
				else if(Option == 5)
				{
					int Print_Flights;

					system("@cls||clear");
					cout << "=========================================================================================================" << endl;
					cout << endl << "1) Print ALL Flights" << endl;
					cout << "2) Print Single Flight" << endl;
					cout << "3) <- GO BACK" << endl << endl;

					cout << ">> ";
					cin >> Print_Flights;

					if(Print_Flights == 1)
					{
						Flight.Print_List(&Plane_Collect, &Crew_Collect, &Plane_Info, &Crew_Info);
					}
					else if(Print_Flights == 2)
					{
						Flight.Print_Single();
					}
					else if(Print_Flights == 3)
					{
						break;
					}
					
				}
				else if(Option == 6)
				{
					break;
				}
				
				break;
			}	// END MANAGE FLIGHTS

			case 4:
			{
				cout << "========================================================" << endl;
				cout << "     Thank you for flying with Mean Green Airlines!     " << endl;
				cout << "========================================================" << endl << endl;
				break;
			}	// END QUIT MESSAGE
			
		}
		
		
		
	}while(Main_Menu != 4); 	// END OF DO WHILE


	return 0;
} // END OF MAIN
