#ifndef FLIGHTS_H
#define FLIGHTS_H

// Class Declarations
#include <string>

using namespace std;

// Class Flights, with private variables and public functions
class Flights
{
    private:
        int Flight_ID;
            int Plane_ID;
            int Pilot_ID;
            int CoPilot_ID;
            int Crew_ID_1;
            int Crew_ID_2;
            int Crew_ID_3;
            string Flight_Start_Date;
            string Flight_End_Date;
            string Time;
            string Starting_Airport_Code;
            string Ending_Airport_Code;
            int Num_Of_Passengers;
            int Flight_Status;    

    public:
        Flights();
        Flights(int Flight_ID, int Plane_ID, int Pilot_ID, int CoPilot_ID, int Crew_ID_1, int Crew_ID_2, int Crew_ID_3, string Flight_Start_Date, 
                string Flight_End_Date, string Time, string Starting_Airport_Code, string Ending_Airport_Code, int Num_Of_Passengers, int Flight_Status);

        //Setters
        void Set_Flight_ID(int Flight_ID);
        void Set_Plane_ID(int Plane_ID);
        void Set_Pilot_ID(int Pilot_ID);
        void Set_CoPilot_ID(int CoPilot_ID);

        void Set_Crew_ID_1(int Crew_ID_1);
        void Set_Crew_ID_2(int Crew_ID_2);
        void Set_Crew_ID_3(int Crew_ID_3);

        void Set_Flight_Start_Date(string Flight_Start_Date);
        void Set_Flight_End_Date(string Flight_End_Date);
        void Set_Time(string Time);
        void Set_Starting_Airport_Code(string Starting_Airport_Code);
        void Set_Ending_Airport_Code(string Ending_Airport_Code);
        void Set_Num_Of_Passengers(int Num_Of_Passengers);
        void Set_Flight_Status(int Flight_Status);   

        //Getters
		int Get_Flight_ID() const;
        int Get_Plane_ID() const;
        int Get_Pilot_ID() const;
        int Get_CoPilot_ID() const;

        int Get_Crew_ID_1() const;
        int Get_Crew_ID_2() const;
        int Get_Crew_ID_3() const;

        string Get_Flight_Start_Date() const;
        string Get_Flight_End_Date() const;
        string Get_Time() const;
        string Get_Starting_Airport_Code() const;
        string Get_Ending_Airport_Code() const;
        int Get_Num_Of_Passengers() const;
        string Get_Flight_Status() const; 

};

#endif