#ifndef FLIGHTS_COLLECTIONS_H
#define FLIGHTS_COLLECTIONS_H

// Class Declarations
#include <string>

// Header Files 
#include "Flights.h"
#include "Plane_Collections.h"
#include "Crew_Collections.h"
#include "Plane.h"
#include "Crew.h"

using namespace std;

// Class Flights, has private and a public
class Flights_Collections
{
    private:
        map <int, Flights> Flights_List;

    public:
        Flights_Collections();
        ~Flights_Collections();
		
		void Add(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew *Crew_Info);
		void Edit(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew * Crew_Info);
		void Delete();
		void Delete_All();
		void Search();
		void Print_List(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew * Crew_Info);
		void Print_Single();

};

#endif