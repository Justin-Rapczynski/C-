// Class Declarations 
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <fstream>

// Header Files
#include "Plane_Collections.h"


int Temp_Plane_ID = 0;			// Crew ID and Tracker
map <int, Plane>::iterator Plane_Iter;		// Map Iterator

using namespace std;

//	Default Constructor
Plane_Collections::Plane_Collections()
{
	Plane Temp;

	string Temp_Make;			//1
	string Temp_Model;			//2
	string Temp_Tail_Number;	//3
	int Temp_Seats;				//4
	int Temp_Range;				//5
	int Temp_Status;			//6


		fstream File;
		File.open("Planes");

		if(File.fail())
  		{
    		cout << "Error, could not open file" << endl;
    		exit(EXIT_FAILURE);
  		}

	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		File >> Temp_Plane_ID;
		File >> Temp_Make; 
		File >> Temp_Model; 
		File >> Temp_Tail_Number;
		File >> Temp_Seats;
		File >> Temp_Range; 
		File >> Temp_Status;

		Temp.Set_Plane_ID(Temp_Plane_ID);
		Temp.Set_Make(Temp_Make);
		Temp.Set_Model(Temp_Model);
		Temp.Set_Tail_Number(Temp_Tail_Number);
		Temp.Set_Seats(Temp_Seats);
		Temp.Set_Range(Temp_Range);
		Temp.Set_Status(Temp_Status);
		
		Plane_List.emplace(Temp_Plane_ID, Temp);

	}

	File.close();

}

// Destructor that writes information to a file
Plane_Collections::~Plane_Collections()
{
	fstream File;
	File.open("Planes");

	if(File.fail())
  	{
    	cout << "Error, could not open file" << endl;
    	exit(EXIT_FAILURE);
  	}

	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		File << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << "   Make: " << Plane_Iter -> second.Get_Make() << "   Model: " 
			 << Plane_Iter -> second.Get_Model() << "   Tail Number: " << Plane_Iter -> second.Get_Tail_Number() << "   Seats: " 
			 << Plane_Iter -> second.Get_Seats() << "   Range: " << Plane_Iter -> second.Get_Range() << "   Status: " << Plane_Iter -> second.Get_Status() << endl; 		
	}	

	File.close();
		

}

// Function that adds PLANES to the map
void Plane_Collections::Add()
{
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	Plane Temp;

	string Temp_Make;			//1
	string Temp_Model;			//2
	string Temp_Tail_Number;	//3
	int Temp_Seats;				//4
	int Temp_Range;				//5
	int Temp_Status;			//6
		
	cin.ignore();
		
	//1
	cout << "Please enter the Make of the Plane" << endl;
	cout << ">> "; 
		
	getline(cin, Temp_Make);
		
		
	//2
	cout << "Please enter the Model of the Plane" << endl;
	cout << ">> "; 
		
	getline(cin, Temp_Model);
		
		
	//3
	cout << "Please enter the Tail Number of the Plane" << endl;
	cout << ">> "; 
		
	getline(cin, Temp_Tail_Number);
		
		
	//4
	cout << "Please enter the Number of Seats the Plane has" << endl;
	cout << ">> "; 
	cin >> Temp_Seats;
		
		
	//5
	cout << "Please enter the Range of the Plane (In Miles)" << endl;
	cout << ">> "; 
	cin >> Temp_Range;
		
		
	//6
	cout << "Please enter the Status of the Plane (Number)" << endl;
	cout << "1) OUT (In Flight)" << endl;
	cout << "2) IN (Available)" << endl;
	cout << "3) REPAIR (Out for Repair)" << endl;
	cout << ">> ";
	cin >> Temp_Status;
	cout << endl;
		
	cout << "---------- GOT DATA! ----------" << endl;

		
	Temp.Set_Plane_ID(Temp_Plane_ID);
	Temp.Set_Make(Temp_Make);
	Temp.Set_Model(Temp_Model);
	Temp.Set_Tail_Number(Temp_Tail_Number);
	Temp.Set_Seats(Temp_Seats);
	Temp.Set_Range(Temp_Range);
	Temp.Set_Status(Temp_Status);
		
	Plane_List.emplace(Temp_Plane_ID, Temp);

	Temp_Plane_ID = Temp_Plane_ID + 1;	

}

// Function capable of editing the information of each PLANES
void Plane_Collections::Edit()
{
		
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Plane ID's --------------------" << endl;
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		cout << "Plane ID Number: " << Plane_Iter-> second.Get_Plane_ID() << endl;
	}

		
	cout << "=========================================================================================================" << endl;
	int ID;

		
	cout << "Please Enter the ID Plane Number that you would like to Modify" << endl;
	cout << ">> ";
	cin >> ID;

	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Current Plane Information --------------------" << endl;
	if(Plane_List.count(ID) == 1)
	{

		cout << "Plane ID Number: " << Plane_List.at(ID).Get_Plane_ID() <<"   Make: " << Plane_List.at(ID).Get_Make() << "   Model: " << Plane_List.at(ID).Get_Model() << "   Tail Number: " 
			 << Plane_List.at(ID).Get_Tail_Number() << "   Seats: " << Plane_List.at(ID).Get_Seats() << "   Range: " << Plane_List.at(ID).Get_Range()
			 << "   Status: " << Plane_List.at(ID).Get_Status() << endl; 				 
		
		
		cout << "=========================================================================================================" << endl;

		Plane_List.erase(ID);

		Plane Temp;

		string Temp_Make;			//1
		string Temp_Model;			//2
		string Temp_Tail_Number;	//3
		int Temp_Seats;				//4
		int Temp_Range;				//5
		int Temp_Status;			//6
		
		cin.ignore();

		//1
		cout << "Please enter the Make of the Plane" << endl;
		cout << ">> "; 

		getline(cin, Temp_Make);
		
		
		//2
		cout << "Please enter the Model of the Plane" << endl;
		cout << ">> "; 
	
		getline(cin, Temp_Model);


		//3
		cout << "Please enter the Tail Number of the Plane" << endl;
		cout << ">> "; 
		
		getline(cin, Temp_Tail_Number);
		
		
		//4
		cout << "Please enter the Number of Seats the Plane has" << endl;
		cout << ">> "; 
		cin >> Temp_Seats;
		
	
		//5
		cout << "Please enter the Range of the Plane (In Miles)" << endl;
		cout << ">> "; 
		cin >> Temp_Range;


		//6
		cout << "Please enter the Status of the Plane (Number)" << endl;
		cout << "1) OUT (In Flight)" << endl;
		cout << "2) IN (Available)" << endl;
		cout << "3) REPAIR (Out for Repair)" << endl;
		cout << ">> ";
		cin >> Temp_Status;
		cout << endl;
		
		cout << "---------- GOT DATA! ----------" << endl;

		Temp.Set_Plane_ID(ID);
		Temp.Set_Make(Temp_Make);
		Temp.Set_Model(Temp_Model);
		Temp.Set_Tail_Number(Temp_Tail_Number);
		Temp.Set_Seats(Temp_Seats);
		Temp.Set_Range(Temp_Range);
		Temp.Set_Status(Temp_Status);
		
		Plane_List.emplace(ID, Temp);
	}
		
	else
	{
		cout << "Sorry, Our database does not contain that ID Plane number" << endl;
	}
		

}
	
// Delete Function Deletes a single PLANES given by the user	
void Plane_Collections::Delete()
{

	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Plane ID's --------------------" << endl;
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << endl;
	}

		
	cout << "=========================================================================================================" << endl;
	int ID;

	cout << "Please Enter the ID Plane Number that you would like to Delete" << endl;
	cout << ">> ";
	cin >> ID;
	Plane_List.erase(ID);
	cout << "-------------------- Plane Deleted! --------------------" << endl;

}

// Delete Function Deletes every single PLANE
void Plane_Collections::Delete_All()
{
	int Delete_All_Planes;

	system("@cls||clear");
	cout << "=========================================================================================================" << endl;
	cout << "Are you sure you want to delete ALL the planes?" << endl;
	cout << "1) Yes" << endl;
	cout << "2) No" << endl;

	cout << ">> ";
	cin >> Delete_All_Planes;

	if (Delete_All_Planes == 1)
	{
		Plane_List.clear();
		Temp_Plane_ID = 0;
		cout << "-------------------- All Planes are Deleted! --------------------" << endl;
	}
	else if(Delete_All_Planes == 2)
	{
		cout << "-------------------- Good Idea! --------------------" << endl;
	}
		
}

// True or False function that determines if PLANE is available or not
bool Plane_Collections::Planes_Available_Counter()
{
	bool Checker;

	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{

		if(Plane_Iter -> second.Get_Status() == "IN (Available)")
		{
			Checker = true;
		}
		else if(Plane_Iter -> second.Get_Status() != "IN (Available)")
		{
			Checker = false;
		}
	}

	return Checker;
}

// Function that prints the AVAILABLE planes
void Plane_Collections::Print_Planes_Available()
{
		
	cout << "=========================================================================================================" << endl;
	cout << "---------------------------------------- Air Planes Available ----------------------------------------" << endl;
		
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
			
		if(Plane_Iter -> second.Get_Status() == "IN (Available)")
		{
			cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << "   Make: " << Plane_Iter -> second.Get_Make() << "   Model: " 
				 << Plane_Iter -> second.Get_Model() << "   Tail Number: " << Plane_Iter -> second.Get_Tail_Number() << "   Seats: " 
				 << Plane_Iter -> second.Get_Seats() << "   Range: " << Plane_Iter -> second.Get_Range() << "   Status: " << Plane_Iter -> second.Get_Status() << endl; 
		}
			
	}	
		
}

// Function that prints the Planes that are flying		
void Plane_Collections::Print_Planes_Out()
{
		
	cout << "=========================================================================================================" << endl;
		
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
			
		if(Plane_Iter -> second.Get_Status() == "OUT (In Flight)")
		{
			cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << "   Make: " << Plane_Iter -> second.Get_Make() << "   Model: " 
				 << Plane_Iter -> second.Get_Model() << "   Tail Number: " << Plane_Iter -> second.Get_Tail_Number() << "   Seats: " 
				 << Plane_Iter -> second.Get_Seats() << "   Range: " << Plane_Iter -> second.Get_Range() << "   Status: " << Plane_Iter -> second.Get_Status() << endl; 
		}
			
	}
		
}
	
// Function that prints the planes that are currently in Repair
void Plane_Collections::Print_Planes_Repair()
{
		
	cout << "=========================================================================================================" << endl;
		
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
			
		if(Plane_Iter -> second.Get_Status() == "REPAIR (Out for Repair)")
		{
			cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << "   Make: " << Plane_Iter -> second.Get_Make() << "   Model: " 
				 << Plane_Iter -> second.Get_Model() << "   Tail Number: " << Plane_Iter -> second.Get_Tail_Number() << "   Seats: " 
				 << Plane_Iter -> second.Get_Seats() << "   Range: " << Plane_Iter -> second.Get_Range() << "   Status: " << Plane_Iter -> second.Get_Status() << endl; 
		}
			
	}
		
}

// TRUE OR FALSE Function Searches if the plane is available or not	
bool Plane_Collections::Search_Available(int Num)
{
	bool Checker;

	for(int i = 0; i < Plane_List.size(); i++)
	{
		
		if(Plane_List.count(Num) == 1)
		{
			Checker = true;
		}
		else
		{
			Checker = false;
		}
		
	}
			
	return Checker;
}

// FUNCTION that updates the availability of the plane
void Plane_Collections::Update_Plane_Availabilty(int Num)
{
	int Availability_Changed;
	for(int i = 0; i < Plane_List.size(); i++)
	{
		if(Plane_List.at(i).Get_Plane_ID() == Num)
		{
			if(Plane_List.at(i).Get_Status() == "IN (Available)")
			{
				Availability_Changed = 1;
				Plane_List.at(i).Set_Status(Availability_Changed);
			}
		}		
	}	
}

// Planes that changes the availability of the plane back to AVAILABLE 
void Plane_Collections::Revert_Plane_Availabilty(int Num)
{
	int Availability_Changed;
	for(int i = 0; i < Plane_List.size(); i++)
	{
		if(Plane_List.at(i).Get_Plane_ID() == Num)
		{
			if(Plane_List.at(i).Get_Status() == "OUT (In Flight)")
			{
				Availability_Changed = 2;
				Plane_List.at(i).Set_Status(Availability_Changed);
			}
		}		
	}	
}

// FUNCTION THAT PRINTS HOW MANY SEATS ARE AVAILABLE 
void Plane_Collections::Print_Available_Seats(int Num)
{
	if(Plane_List.count(Num) == 1)
	{

		cout << "Plane ID Number: " << Plane_List.at(Num).Get_Plane_ID() << "   Seats Available: " << Plane_List.at(Num).Get_Seats() << endl;
	}
	
}	

// FUNCTION THAT DETERMINES IF THE INPUT OF THE USER IS APPROPIATE FOR THE SEATS AVAILABLE
void Plane_Collections::Seats_Available(int Num)
{
	int New_Total;
		
	for(int i = 0; i < Plane_List.size(); i++)
	{
		if(Num <= Plane_List.at(i).Get_Seats())
		{
			New_Total = Plane_List.at(i).Get_Seats() - Num;
			Plane_List.at(i).Set_Seats(New_Total);
			cout << "Seats Remaining: " <<  Plane_List.at(i).Get_Seats() << endl;
		}
		else if(Num > Plane_List.at(i).Get_Seats())
		{
			cout << "Not enough Seats Available. Sorry!" << endl;
			cout << "Here is a promo code for the inconvenience (Promo Code - DillyDilly)" << endl;
			break;
		}
	}
}

// FUNCTION THAT PRINTS ALL THE PLANES WITHIN THE MAP ITERATOR	
void Plane_Collections::Print_List()
{
		
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		//cout << "Make: " << Plane_Iter -> second.Get_Make() << endl;

		cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << "   Make: " << Plane_Iter -> second.Get_Make() << "   Model: " 
			 << Plane_Iter -> second.Get_Model() << "   Tail Number: " << Plane_Iter -> second.Get_Tail_Number() << "   Seats: " 
			 << Plane_Iter -> second.Get_Seats() << "   Range: " << Plane_Iter -> second.Get_Range() << "   Status: " << Plane_Iter -> second.Get_Status() << endl; 
			
	}		
		
}

// FUNCTION THAT PRINTS ALL A SINGLE PLANE BASED ON THE INPUT OF THE USER
void Plane_Collections::Print_Single()
{

	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Plane ID's --------------------" << endl;
	for (Plane_Iter = Plane_List.begin(); Plane_Iter != Plane_List.end(); Plane_Iter++)
	{
		cout << "Plane ID Number: " << Plane_Iter -> second.Get_Plane_ID() << endl;
	}
		
	cout << "=========================================================================================================" << endl;
	int ID;
		
	cout << "Please Enter the ID Plane Number you would like to see" << endl;
	cout << ">> ";
	cin >> ID;

	cout << "=========================================================================================================" << endl;
	if(Plane_List.count(ID) == 1)
	{

		cout << "Plane ID Number: " << Plane_List.at(ID).Get_Plane_ID() <<"   Make: " << Plane_List.at(ID).Get_Make() << "   Model: " << Plane_List.at(ID).Get_Model() << "   Tail Number: " 
			 << Plane_List.at(ID).Get_Tail_Number() << "   Seats: " << Plane_List.at(ID).Get_Seats() << "   Range: " << Plane_List.at(ID).Get_Range()
			 << "   Status: " << Plane_List.at(ID).Get_Status() << endl; 				 
	}
	else
	{
		cout << "Sorry, Our database does not contain that ID Plane number" << endl;
	}

}




