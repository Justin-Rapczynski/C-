// Class Declarations
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include <map>

#include "Flights_Collections.h"


int Temp_Flight_ID = 0;							//1	ID TRACKER AND COUNTER
map <int, Flights>::iterator Flights_Iter;		// MAP ITERATOR

// Default Constructor
Flights_Collections::Flights_Collections()		
{
    
}

// Destructor used to read to a file after the program ends
Flights_Collections::~Flights_Collections()		
{
	fstream File;
	File.open("Flights");

	if(File.fail())
  	{
    	cout << "Error, could not open file" << endl;
    	exit(EXIT_FAILURE);
  	}

	for(int i = 0; i < Flights_List.size(); i++)
	{

		File << "Flight ID Number: " << Flights_List.at(i).Get_Flight_ID() << "   Pilot ID: " << Flights_List.at(i).Get_Pilot_ID()
			 << "   CoPilot ID: " << Flights_List.at(i).Get_CoPilot_ID() << "   Crew Member (1 of 3): " << Flights_List.at(i).Get_Crew_ID_1()
			 << "   Crew Member (2 of 3): " << Flights_List.at(i).Get_Crew_ID_2() << "   Crew Member (3 of 3): " << Flights_List.at(i).Get_Crew_ID_3()
			 << 	"   Flight Start Date: " << Flights_List.at(i).Get_Flight_Start_Date() 
			 << "   Flight End Date: " << Flights_List.at(i).Get_Flight_End_Date() << "   Flight Time: "
			 << Flights_List.at(i).Get_Time() << "   Starting Airport Code: " << Flights_List.at(i).Get_Starting_Airport_Code()
			 << "   Ending Airport Code: " << Flights_List.at(i).Get_Ending_Airport_Code() << "   Number of Passengers: "
			 << Flights_List.at(i).Get_Num_Of_Passengers() << "   Flight Status: " << Flights_List.at(i).Get_Flight_Status() << endl;
			 
	}	

	File.close();

}

// Function Capable of Adding Planes and Crews together into one in order to create Flights. The proram knows which
// Crew members are available and displays them for the user to choose From. The Adding function is a smart very fast and user
// friendly interface.
void Flights_Collections::Add(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew * Crew_Info)
{
	Flights Temp;
    
    int Temp_Plane_ID;							//2
    int Temp_Pilot_ID;							//3
    int Temp_CoPilot_ID;						//4

    int Temp_Crew_ID_1;							//5
	int Temp_Crew_ID_2;							//5.2
	int Temp_Crew_ID_3;							//5.3

    string Temp_Flight_Start_Date;				//6
    string Temp_Flight_End_Date;				//7
    string Temp_Time;							//8
    string Temp_Starting_Airport_Code;			//9
    string Temp_Ending_Airport_Code;			//10
    int Temp_Num_Of_Passengers;					//11
    int Temp_Flight_Status;						//12
	
	
	
	int Adding_Flight;
	do
	{
		system("@cls||clear");
		cout << "=========================================================================================================" << endl;
		cout << "1) Would you like to add a flight" << endl;
		cout << "2) <- EXIT" << endl << endl;
		cout << ">> ";
		cin >> Adding_Flight;
	
	
		if(Adding_Flight == 1)
		{
			//1
			Temp.Set_Flight_ID(Temp_Flight_ID);
	

			// Plane
			cout << "=========================================================================================================" << endl;
	
			if(Plane_Collect -> Planes_Available_Counter() == false)
			{
				cout << "\t\t NO AVAILABLE PLANES IN OUR SYSTEM. Please ADD AVAILABLE PLANES" << endl << endl;
				break;
			}

			else if(Plane_Collect -> Planes_Available_Counter() == true)
			{
				Plane_Collect -> Print_Planes_Available();
				cout << endl;

				cout << "Please enter the Plane ID Number in order to create a flight" << endl;
				cout << ">> ";
				cin >> Temp_Plane_ID;

				if(Plane_Collect -> Search_Available(Temp_Plane_ID) == true)
				{
					//2
					Temp.Set_Plane_ID(Temp_Plane_ID);
					Plane_Collect -> Update_Plane_Availabilty(Temp_Plane_ID);
				}
		
				else 
				{
					cout << "Error, Wrong ID Plane Number. Please Try Again" << endl;
					break;
				}

		
			}
	
	
	
	
			//Pilot
			cout << "=========================================================================================================" << endl;

			if(Crew_Collect -> Pilots_Available_Counter() == false)
			{
				Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
				cout << "\t\t NO AVAILABLE PILOTS IN OUR SYSTEM. Please ADD AVAILABLE PILOTS" << endl << endl;
				break;
			}

			else if(Crew_Collect -> Pilots_Available_Counter() == true)
			{
				Crew_Collect -> Print_Pilots_Available();
				cout << endl;
	
				cout << "Please select the Pilot you want" << endl;
				cout << ">> ";
				cin >> Temp_Pilot_ID;
	
				if(Crew_Collect -> Search_Available(Temp_Pilot_ID) == true)
				{
					//3
					Temp.Set_Pilot_ID(Temp_Pilot_ID);
					Crew_Collect -> Update_Availabilty(Temp_Pilot_ID);
				}
				else
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					cout << "Error, Wrong Pilot ID Number. Please Try Again" << endl;
					break;
				}

			}
	
	
	
			//Co Pilot
			cout << "=========================================================================================================" << endl;
	
			if(Crew_Collect -> Crew_Available_Counter() == false)
			{
				Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
				Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
				cout << "\t\t NO Co PILOTS IN OUR SYSTEM. Please ADD AVAILABLE CoPILOTS" << endl << endl;
				break;
			}
	
			else if(Crew_Collect -> CoPilots_Available_Counter() == true)
			{
				Crew_Collect -> Print_CoPilots_Available();
				cout << endl;	
	
				cout << "Please select the CoPilot you want" << endl;
				cout << ">> ";
				cin >> Temp_CoPilot_ID;

				if(Crew_Collect -> Search_Available(Temp_CoPilot_ID) == true)
				{
					//4
					Temp.Set_CoPilot_ID(Temp_CoPilot_ID);
					Crew_Collect -> Update_Availabilty(Temp_CoPilot_ID);
				}
				else
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					cout << "Error, Wrong CoPilot ID Number. Please Try Again" << endl;
					break;
				}
		
			}
	

	
			// Crew 1
			cout << "=========================================================================================================" << endl;
	
			if(Crew_Collect -> Crew_Available_Counter() == false)
			{
				Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
				Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
				Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
				cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
				break;
			}
	
			else if(Crew_Collect -> Crew_Available_Counter() == true)
			{
				
				//----------------------------------------------------------------------------------------
				Crew_Collect -> Print_Crew_Available();
				cout << endl;

				cout << "Please select the 3 Crew Members you want. (1 of 3)" << endl;
				cout << ">> ";
				cin >> Temp_Crew_ID_1;

				if(Crew_Collect -> Search_Available(Temp_Crew_ID_1) == true)
				{
					//5
					Temp.Set_Crew_ID_1(Temp_Crew_ID_1);
					Crew_Collect -> Update_Availabilty(Temp_Crew_ID_1);
				}
				else
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_1);
					cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
					break;
				}
				
			}	
				
				
			// Crew #2
			cout << "=========================================================================================================" << endl;
	
			if(Crew_Collect -> Crew_Available_Counter() == false)
			{
				Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
				Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
				Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
				cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
				break;
			}
	
			else if(Crew_Collect -> Crew_Available_Counter() == true)
			{	

				//----------------------------------------------------------------------------------------
				Crew_Collect -> Print_Crew_Available();
				cout << endl;

				cout << "Please select the 3 Crew Members you want. (2 of 3)" << endl;
				cout << ">> ";
				cin >> Temp_Crew_ID_2;

				if(Crew_Collect -> Search_Available(Temp_Crew_ID_2) == true)
				{
					//5
					Temp.Set_Crew_ID_2(Temp_Crew_ID_2);
					Crew_Collect ->Update_Availabilty(Temp_Crew_ID_2);
				}
				else
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_1);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_2);
					cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
					break;
				}
				
			}	

			// Crew #3
			cout << "=========================================================================================================" << endl;

			if(Crew_Collect -> Crew_Available_Counter() == false)
			{
				Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
				Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
				Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
				cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
				break;
			}
	
			else if(Crew_Collect -> Crew_Available_Counter() == true)
			{	
			
				//----------------------------------------------------------------------------------------
				Crew_Collect -> Print_Crew_Available();
				cout << endl;

				cout << "Please select the 3 Crew Members you want. (3 of 3)" << endl;
				cout << ">> ";
				cin >> Temp_Crew_ID_3;

				if(Crew_Collect -> Search_Available(Temp_Crew_ID_3) == true)
				{
					//5
					Temp.Set_Crew_ID_3(Temp_Crew_ID_3);
					Crew_Collect -> Update_Availabilty(Temp_Crew_ID_3);
				}
				else
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_1);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_2);
					Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_3);
					cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
					break;
				}
		
		
			}


			if(Crew_Collect -> Crew_Available_Counter() == false)
			{
				Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_1);
				Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_2);
				Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_3);
			}

	
			cin.ignore();
			
	
			// Flights Start Date
			cout << "=========================================================================================================" << endl;
			cout << "Please enter the Flights Start Date MM/DD/YYYY" << endl;
			cout << ">> ";
			cin >> Temp_Flight_Start_Date;
			Temp.Set_Flight_Start_Date(Temp_Flight_Start_Date); 		//6


			// Flights End Date
			cout << "=========================================================================================================" << endl;
			cout << "Please enter the Flights End Date MM/DD/YYYY" << endl;
			cout << ">> ";
			cin >> Temp_Flight_End_Date;
			Temp.Set_Flight_End_Date(Temp_Flight_End_Date);				//7

	
			// Flight Time
			cout << "=========================================================================================================" << endl;
			cout << "Please Enter the time of the Flight in GMT (Ex: 10:30)" << endl;
			cout << ">> ";
			cin >> Temp_Time;
			Temp.Set_Time(Temp_Time);									//8
	
	
			// Starting Airport Code
			cout << "=========================================================================================================" << endl;
			cout << "Please enter the Starting Airport Code (Ex: LAX)" << endl;
			cout << ">> ";
			cin >> Temp_Starting_Airport_Code;
			Temp.Set_Starting_Airport_Code(Temp_Starting_Airport_Code); //9
	
	
			// Ending Airport Code
			cout << "=========================================================================================================" << endl;
			cout << "Please enter the Ending Airport Code (Ex: DAL)" << endl;
			cout << ">> ";
			cin >> Temp_Ending_Airport_Code;
			Temp.Set_Ending_Airport_Code(Temp_Ending_Airport_Code);		//10
	
	
			// Number of Passengers
			cout << "=========================================================================================================" << endl;
			Plane_Collect -> Print_Available_Seats(Temp_Plane_ID);
			cout << endl;
	
			cout << "Please enter the Number of Passengers" << endl;
			cout << ">> ";
			cin >> Temp_Num_Of_Passengers;
	
			Plane_Collect -> Seats_Available(Temp_Num_Of_Passengers);
	
			Temp.Set_Num_Of_Passengers(Temp_Num_Of_Passengers);			//11
	
	
			// Status of Flight
			cout << "=========================================================================================================" << endl;
			cout << "Please enter the Status of the Flight" << endl;
			cout << "1) Available" << endl;
			cout << "2) Cancelled" << endl;
			cout << "3) Completed" << endl;
			cout << ">> ";
			cin >> Temp_Flight_Status;
			Temp.Set_Flight_Status(Temp_Flight_Status);					//12
	
	
	
			Flights_List.emplace(Temp_Flight_ID, Temp);

			Temp_Flight_ID = Temp_Flight_ID + 1;	

			break;
		
		}
	
		else if(Adding_Flight == 2)
		{
			break;
		}
	

	}while(Adding_Flight != 2);
	
	cout << Temp_Flight_ID << endl;
	

}

// Function Capable of Editing The information of a flight. It can change everything from the plane to the pilot, copilot, crew, starting date
// etc
void Flights_Collections::Edit(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew * Crew_Info)
{
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "---------------------------------------- Flight ID's ----------------------------------------" << endl;
	for (Flights_Iter = Flights_List.begin(); Flights_Iter != Flights_List.end(); Flights_Iter++)
	{
		cout << "Flight ID Number: " << Flights_Iter-> second.Get_Flight_ID() << endl;
	}

		
	cout << "=========================================================================================================" << endl;
	int ID;

		
	cout << "Please Enter the Flight ID Number that you would like to Modify" << endl;
	cout << ">> ";
	cin >> ID;

	cout << "=========================================================================================================" << endl;

	cout << "---------------------------------------- Current Flight Information ----------------------------------------" << endl;
	if(Flights_List.count(ID) == 1)
	{

		cout << "Flight ID Number: " << Flights_List.at(ID).Get_Flight_ID() << "   Pilot ID: " << Flights_List.at(ID).Get_Pilot_ID()
			 << "   CoPilot ID: " << Flights_List.at(ID).Get_CoPilot_ID() << "   Crew Member (1 of 3): " << Flights_List.at(ID).Get_Crew_ID_1()
			 << "   Crew Member (2 of 3): " << Flights_List.at(ID).Get_Crew_ID_2() << "   Crew Member (3 of 3): " << Flights_List.at(ID).Get_Crew_ID_3()
			 << 	"   Flight Start Date: " << Flights_List.at(ID).Get_Flight_Start_Date() 
			 << "   Flight End Date: " << Flights_List.at(ID).Get_Flight_End_Date() << "   Flight Time: "
			 << Flights_List.at(ID).Get_Time() << "   Starting Airport Code: " << Flights_List.at(ID).Get_Starting_Airport_Code()
			 << "   Ending Airport Code: " << Flights_List.at(ID).Get_Ending_Airport_Code() << "   Number of Passengers: "
			 << Flights_List.at(ID).Get_Num_Of_Passengers() << "   Flight Status: " << Flights_List.at(ID).Get_Flight_Status() << endl;
	
		Flights Temp;
    
    	int Temp_Plane_ID;							//2
    	int Temp_Pilot_ID;							//3
    	int Temp_CoPilot_ID;						//4

    	int Temp_Crew_ID_1;							//5
		int Temp_Crew_ID_2;							//5.2
		int Temp_Crew_ID_3;							//5.3

    	string Temp_Flight_Start_Date;				//6
    	string Temp_Flight_End_Date;				//7
    	string Temp_Time;							//8
    	string Temp_Starting_Airport_Code;			//9
    	string Temp_Ending_Airport_Code;			//10
    	int Temp_Num_Of_Passengers;					//11
    	int Temp_Flight_Status;						//12
	
	
		int Adding_Flight;
		
		do
		{
			system("@cls||clear");
			cout << "=========================================================================================================" << endl;
			cout << "1) Would you like to add a flight" << endl;
			cout << "2) <- EXIT" << endl << endl;
			cout << ">> ";
			cin >> Adding_Flight;
	
	
			if(Adding_Flight == 1)
			{
				//1
				Temp.Set_Flight_ID(ID);
	

				// Plane
				cout << "=========================================================================================================" << endl;
	
				if(Plane_Collect -> Planes_Available_Counter() == false)
				{
					cout << "\t\t NO AVAILABLE PLANES IN OUR SYSTEM. Please ADD AVAILABLE PLANES" << endl << endl;
					break;
				}

				else if(Plane_Collect -> Planes_Available_Counter() == true)
				{
					Plane_Collect -> Print_Planes_Available();
					cout << endl;

					cout << "Please enter the Plane ID Number in order to create a flight" << endl;
					cout << ">> ";
					cin >> Temp_Plane_ID;

					if(Plane_Collect -> Search_Available(Temp_Plane_ID) == true)
					{
						//2
						Temp.Set_Plane_ID(Temp_Plane_ID);
						Plane_Collect -> Update_Plane_Availabilty(Temp_Plane_ID);
					}
		
					else 
					{
						cout << "Error, Wrong ID Plane Number. Please Try Again" << endl;
						break;
					}

		
				}
	
	
	
	
				//Pilot
				cout << "=========================================================================================================" << endl;

				if(Crew_Collect -> Pilots_Available_Counter() == false)
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					cout << "\t\t NO AVAILABLE PILOTS IN OUR SYSTEM. Please ADD AVAILABLE PILOTS" << endl << endl;
					break;
				}

				else if(Crew_Collect -> Pilots_Available_Counter() == true)
				{
					Crew_Collect -> Print_Pilots_Available();
					cout << endl;
	
					cout << "Please select the Pilot you want" << endl;
					cout << ">> ";
					cin >> Temp_Pilot_ID;
	
					if(Crew_Collect -> Search_Available(Temp_Pilot_ID) == true)
					{
						//3
						Temp.Set_Pilot_ID(Temp_Pilot_ID);
						Crew_Collect -> Update_Availabilty(Temp_Pilot_ID);
					}
					else
					{
						Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
						cout << "Error, Wrong Pilot ID Number. Please Try Again" << endl;
						break;
					}

				}
	
	
	
				//Co Pilot
				cout << "=========================================================================================================" << endl;
	
				if(Crew_Collect -> Crew_Available_Counter() == false)
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					cout << "\t\t NO Co PILOTS IN OUR SYSTEM. Please ADD AVAILABLE CoPILOTS" << endl << endl;
					break;
				}
	
				else if(Crew_Collect -> CoPilots_Available_Counter() == true)
				{
					Crew_Collect -> Print_CoPilots_Available();
					cout << endl;	
	
					cout << "Please select the CoPilot you want" << endl;
					cout << ">> ";
					cin >> Temp_CoPilot_ID;

					if(Crew_Collect -> Search_Available(Temp_CoPilot_ID) == true)
					{
						//4
						Temp.Set_CoPilot_ID(Temp_CoPilot_ID);
						Crew_Collect -> Update_Availabilty(Temp_CoPilot_ID);
					}
					else
					{
						Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
						cout << "Error, Wrong CoPilot ID Number. Please Try Again" << endl;
						break;
					}
		
				}
	

	
				// Crew
				cout << "=========================================================================================================" << endl;
	
				if(Crew_Collect -> Crew_Available_Counter() == false)
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
					break;
				}
	
				else if(Crew_Collect -> Crew_Available_Counter() == true)
				{
				
					//----------------------------------------------------------------------------------------
					Crew_Collect -> Print_Crew_Available();
					cout << endl;

					cout << "Please select the 3 Crew Members you want. (1 of 3)" << endl;
					cout << ">> ";
					cin >> Temp_Crew_ID_1;

					if(Crew_Collect -> Search_Available(Temp_Crew_ID_1) == true)
					{
						//5
						Temp.Set_Crew_ID_1(Temp_Crew_ID_1);
						Crew_Collect -> Update_Availabilty(Temp_Crew_ID_1);
					}
					else
					{
						Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
						Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
						cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
						break;
					}
				
				}	
				
				
				// Crew #2
				cout << "=========================================================================================================" << endl;
	
				if(Crew_Collect -> Crew_Available_Counter() == false)
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
					break;
				}
	
				else if(Crew_Collect -> Crew_Available_Counter() == true)
				{	

					//----------------------------------------------------------------------------------------
					Crew_Collect -> Print_Crew_Available();
					cout << endl;

					cout << "Please select the 3 Crew Members you want. (2 of 3)" << endl;
					cout << ">> ";
					cin >> Temp_Crew_ID_2;

					if(Crew_Collect -> Search_Available(Temp_Crew_ID_2) == true)
					{
						//5
						Temp.Set_Crew_ID_2(Temp_Crew_ID_2);
						Crew_Collect ->Update_Availabilty(Temp_Crew_ID_2);
					}
					else
					{
						Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_1);
						cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
						break;
					}
				
				}		

				if(Crew_Collect -> Crew_Available_Counter() == false)
				{
					Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
					Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
					Crew_Collect -> Revert_Availabilty(Temp_CoPilot_ID);
					cout << "\t\t NO ENOUGH CREW IN OUR SYSTEM. Please ADD AVAILABLE CREW" << endl << endl;
					break;
				}
	
				else if(Crew_Collect -> Crew_Available_Counter() == true)
				{	
			
					//----------------------------------------------------------------------------------------
					Crew_Collect -> Print_Crew_Available();
					cout << endl;

					cout << "Please select the 3 Crew Members you want. (3 of 3)" << endl;
					cout << ">> ";
					cin >> Temp_Crew_ID_3;

					if(Crew_Collect -> Search_Available(Temp_Crew_ID_3) == true)
					{
						//5
						Temp.Set_Crew_ID_3(Temp_Crew_ID_3);
						Crew_Collect -> Update_Availabilty(Temp_Crew_ID_3);
					}
					else
					{
						Plane_Collect -> Revert_Plane_Availabilty(Temp_Plane_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Pilot_ID);
						Crew_Collect -> Revert_Availabilty(Temp_Crew_ID_2);
						cout << "Error, Wrong Crew ID Number. Please Try Again" << endl;
						break;
					}
		
		
				}
	
	
				cin.ignore();
			
	
				// Flights Start Date
				cout << "=========================================================================================================" << endl;
				cout << "Please enter the Flights Start Date MM/DD/YYYY" << endl;
				cout << ">> ";
				cin >> Temp_Flight_Start_Date;
				Temp.Set_Flight_Start_Date(Temp_Flight_Start_Date); 		//6


				// Flights End Date
				cout << "=========================================================================================================" << endl;
				cout << "Please enter the Flights End Date MM/DD/YYYY" << endl;
				cout << ">> ";
				cin >> Temp_Flight_End_Date;
				Temp.Set_Flight_End_Date(Temp_Flight_End_Date);				//7

	
				// Flight Time
				cout << "=========================================================================================================" << endl;
				cout << "Please Enter the time of the Flight in GMT (Ex: 10:30)" << endl;
				cout << ">> ";
				cin >> Temp_Time;
				Temp.Set_Time(Temp_Time);									//8
	
	
				// Starting Airport Code
				cout << "=========================================================================================================" << endl;
				cout << "Please enter the Starting Airport Code (Ex: LAX)" << endl;
				cout << ">> ";
				cin >> Temp_Starting_Airport_Code;
				Temp.Set_Starting_Airport_Code(Temp_Starting_Airport_Code); //9
	
	
				// Ending Airport Code
				cout << "=========================================================================================================" << endl;
				cout << "Please enter the Ending Airport Code (Ex: DAL)" << endl;
				cout << ">> ";
				cin >> Temp_Ending_Airport_Code;
				Temp.Set_Ending_Airport_Code(Temp_Ending_Airport_Code);		//10
	
	
				// Number of Passengers
				cout << "=========================================================================================================" << endl;
				Plane_Collect -> Print_Available_Seats(Temp_Plane_ID);
				cout << endl;
	
				cout << "Please enter the Number of Passengers" << endl;
				cout << ">> ";
				cin >> Temp_Num_Of_Passengers;
	
				Plane_Collect -> Seats_Available(Temp_Num_Of_Passengers);
	
				Temp.Set_Num_Of_Passengers(Temp_Num_Of_Passengers);			//11
	
	
				// Status of Flight
				cout << "=========================================================================================================" << endl;
				cout << "Please enter the Status of the Flight" << endl;
				cout << "1) Available" << endl;
				cout << "2) Cancelled" << endl;
				cout << "3) Completed" << endl;
				cout << ">> ";
				cin >> Temp_Flight_Status;
				Temp.Set_Flight_Status(Temp_Flight_Status);					//12
	
	
	
				Flights_List.emplace(ID, Temp);
	

				break;
		
			}
	
			else if(Adding_Flight == 2)
			{
				break;
			}
	

		}while(Adding_Flight != 2);
	
		cout << Temp_Flight_ID << endl;			 
			 
	}

}

//Delete Function Deletes a single flight given by the user
void Flights_Collections::Delete()
{
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "---------------------------------------- Flight ID's ----------------------------------------" << endl;
	for (Flights_Iter = Flights_List.begin(); Flights_Iter != Flights_List.end(); Flights_Iter++)
	{
		cout << "Flight ID Number: " << Flights_Iter -> second.Get_Flight_ID()<< endl;
	}

		
	cout << "=========================================================================================================" << endl;
	int ID;

	cout << "Please Enter the Flight ID Number that you would like to Delete" << endl;
	cout << ">> ";
	cin >> ID;
	Flights_List.erase(ID);
	cout << "-------------------- Flight Deleted! --------------------" << endl;

}

// Delete Function Deletes every single flight
void Flights_Collections::Delete_All()
{
	int Delete_All_Flights;

	system("@cls||clear");
	cout << "=========================================================================================================" << endl;
	cout << "Are you sure you want to delete ALL the flights?" << endl;
	cout << "1) Yes" << endl;
	cout << "2) No" << endl;

	cout << ">> ";
	cin >> Delete_All_Flights;

	if (Delete_All_Flights == 1)
	{
		Flights_List.clear();
		Temp_Flight_ID = 0;
		cout << "-------------------- All Flights are Deleted! --------------------" << endl;
	}
	else if(Delete_All_Flights == 2)
	{
		cout << "-------------------- Good Idea! --------------------" << endl;
	}
}

// Class Not USED IN PROGRAM
void Flights_Collections::Search()
{

}

// Function Caplable of printing every FLight in the system
void Flights_Collections::Print_List(Plane_Collections * Plane_Collect, Crew_Collections * Crew_Collect, Plane * Plane_Info, Crew * Crew_Info)
{	
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	for(int i = 0; i < Flights_List.size(); i++)
	{

		cout << "Flight ID Number: " << Flights_List.at(i).Get_Flight_ID() << "   Pilot ID: " << Flights_List.at(i).Get_Pilot_ID()
			 << "   CoPilot ID: " << Flights_List.at(i).Get_CoPilot_ID() << "   Crew Member (1 of 3): " << Flights_List.at(i).Get_Crew_ID_1()
			 << "   Crew Member (2 of 3): " << Flights_List.at(i).Get_Crew_ID_2() << "   Crew Member (3 of 3): " << Flights_List.at(i).Get_Crew_ID_3()
			 << 	"   Flight Start Date: " << Flights_List.at(i).Get_Flight_Start_Date() 
			 << "   Flight End Date: " << Flights_List.at(i).Get_Flight_End_Date() << "   Flight Time: "
			 << Flights_List.at(i).Get_Time() << "   Starting Airport Code: " << Flights_List.at(i).Get_Starting_Airport_Code()
			 << "   Ending Airport Code: " << Flights_List.at(i).Get_Ending_Airport_Code() << "   Number of Passengers: "
			 << Flights_List.at(i).Get_Num_Of_Passengers() << "   Flight Status: " << Flights_List.at(i).Get_Flight_Status() << endl;
			 
	}		

}

// Function that prints a single flight based on the ID number given by the user
void Flights_Collections::Print_Single()
{
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Flight ID's --------------------" << endl;
	for (Flights_Iter = Flights_List.begin(); Flights_Iter != Flights_List.end(); Flights_Iter++)
	{
		cout << "Flight ID Number: " << Flights_Iter -> second.Get_Flight_ID()<< endl;
	}
		
	cout << "=========================================================================================================" << endl;
	int ID;
		
	cout << "Please Enter the Flight ID Number you would like to see" << endl;
	cout << ">> ";
	cin >> ID;

	cout << "=========================================================================================================" << endl;
	
	if(Flights_List.count(ID) == 1)
	{
		cout << "Flight ID Number: " << Flights_List.at(ID).Get_Flight_ID() << "   Pilot ID: " << Flights_List.at(ID).Get_Pilot_ID()
			 << "   CoPilot ID: " << Flights_List.at(ID).Get_CoPilot_ID() << "   Crew Member (1 of 3): " << Flights_List.at(ID).Get_Crew_ID_1()
			 << "   Crew Member (2 of 3): " << Flights_List.at(ID).Get_Crew_ID_2() << "   Crew Member (3 of 3): " << Flights_List.at(ID).Get_Crew_ID_3()
			 << 	"   Flight Start Date: " << Flights_List.at(ID).Get_Flight_Start_Date() 
			 << "   Flight End Date: " << Flights_List.at(ID).Get_Flight_End_Date() << "   Flight Time: "
			 << Flights_List.at(ID).Get_Time() << "   Starting Airport Code: " << Flights_List.at(ID).Get_Starting_Airport_Code()
			 << "   Ending Airport Code: " << Flights_List.at(ID).Get_Ending_Airport_Code() << "   Number of Passengers: "
			 << Flights_List.at(ID).Get_Num_Of_Passengers() << "   Flight Status: " << Flights_List.at(ID).Get_Flight_Status() << endl;

	}
	else
	{
		cout << "Sorry, Our database does not contain that Flight ID Number" << endl;
	}

}