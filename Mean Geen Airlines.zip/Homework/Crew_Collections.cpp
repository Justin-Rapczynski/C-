// Class Declarations 
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include <map>

// Header Files
#include "Crew_Collections.h"


int Temp_Crew_ID = 0;	// Crew ID and Tracker
map <int, Crew>::iterator Crew_Iter;		// Map Iterator

using namespace std;

//	Default Constructor
Crew_Collections::Crew_Collections()
{
		
}

// Destructor that writes information to a file
Crew_Collections::~Crew_Collections()
{
	fstream File;
	File.open("Crew");

	if(File.fail())
  	{
    	cout << "Error, could not open file" << endl;
    	exit(EXIT_FAILURE);
  	}

	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		
		File << "Employee ID: " << Crew_Iter -> second.Get_ID_Number() << "   Name: " << Crew_Iter -> second.Get_Name()
			 << "   Type: " << Crew_Iter -> second.Get_Type() << "   Status: " << Crew_Iter -> second.Get_Status() << endl;
	
	}	

	File.close();
	
}

// Function that adds Crew to the map
void Crew_Collections::Add()
{
	
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;
	
	Crew Temp;
	
	string Temp_Name;	//1
	int Temp_Type;		//2
	int Temp_Status;	//3
	
	cin.ignore();
	
	
	//1
	cout << "Please enter the Employee's Name" << endl;
	cout << ">> ";
	
	getline(cin, Temp_Name);
	
	
	//2
	cout << "Please enter the Type of Employee" << endl;
	cout << "1) Pilot" << endl;
	cout << "2) Co-Pilot" << endl;
	cout << "3) Cabin" << endl;
	cout << ">> ";
	cin >> Temp_Type;
	
	
	//3
	cout << "Please enter the Status of the Employee" << endl;
	cout << "1) Available" << endl;
	cout << "2) On-Leave" << endl;
	cout << "3) Sick" << endl;
	cout << ">> ";
	cin >> Temp_Status;
	cout << endl;
	
	cout << "---------- GOT DATA! ----------" << endl;
	
	
	Temp.Set_Name(Temp_Name);
    Temp.Set_ID_Number(Temp_Crew_ID);
    Temp.Set_Type(Temp_Type);
    Temp.Set_Status(Temp_Status);
	
	Crew_List.emplace(Temp_Crew_ID, Temp);

	Temp_Crew_ID = Temp_Crew_ID + 1;	
	
}

// Function capable of editing the information of each crew member
void Crew_Collections::Edit()
{
	
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Crew ID's --------------------" << endl;
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		cout << "Employee's ID Number: " << Crew_Iter-> second.Get_ID_Number() << endl;
	}

	
	cout << "=========================================================================================================" << endl;
	int ID;

	
	cout << "Please Enter the ID Plane Number that you would like to Modify" << endl;
	cout << ">> ";
	cin >> ID;

	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Current Crew Information --------------------" << endl;
	if(Crew_List.count(ID) == 1)
	{
		cout << "Employee ID: " << Crew_List.at(ID).Get_ID_Number() << "   Name: " << Crew_List.at(ID).Get_Name() 
			 << "   Type: " << Crew_List.at(ID).Get_Type() << "   Status: " << Crew_List.at(ID).Get_Status() << endl;
			 
			 cout << "=========================================================================================================" << endl;
	
	Crew_List.erase(ID);

		Crew Temp;
	
		string Temp_Name;	//1
		int Temp_Type;		//2
		int Temp_Status;	//3
	
		cin.ignore();
	
	
		//1
		cout << "Please enter the Employee's Name" << endl;
		cout << ">> ";
	
		getline(cin, Temp_Name);
	
	
		//2
		cout << "Please enter the Type of Employee" << endl;
		cout << "1) Pilot" << endl;
		cout << "2) Co-Pilot" << endl;
		cout << "3) Cabin" << endl;
		cout << ">> ";
		cin >> Temp_Type;
	
	
		//3
		cout << "Please enter the Status of the Employee" << endl;
		cout << "1) Available" << endl;
		cout << "2) On-Leave" << endl;
		cout << "3) Sick" << endl;
		cout << ">> ";
		cin >> Temp_Status;
		cout << endl;
	
		cout << "---------- GOT DATA! ----------" << endl;
	

		Temp.Set_Name(Temp_Name);
		Temp.Set_ID_Number(ID);
		Temp.Set_Type(Temp_Type);
		Temp.Set_Status(Temp_Status);

	
		Crew_List.emplace(ID, Temp);
		

	}
	
	else
	{
		cout << "Sorry, Our database does not contain that Employee's ID Number" << endl;
	}	
	
	
}

// Delete Function Deletes a single flight given by the user
void Crew_Collections::Delete()
{
	
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;

	cout << "-------------------- Employee ID's --------------------" << endl;
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		cout << "Employee's ID Number: " << Crew_Iter-> second.Get_ID_Number() << endl;
	}
	
	
	cout << "=========================================================================================================" << endl;
	int ID;

	cout << "Please Enter the ID of the Employee you would like to Remove" << endl;
	cout << ">> ";
	cin >> ID;
	Crew_List.erase(ID);
	cout << "-------------------- Employee Deleted! --------------------" << endl;

}

// Delete Function Deletes every single flight
void Crew_Collections::Delete_All()
{
	int Delete_All_Crew;

		system("@cls||clear");
		cout << "=========================================================================================================" << endl;
		cout << "Are you sure you want to delete ALL Employee's?" << endl;
		cout << "1) Yes" << endl;
		cout << "2) No" << endl;

		cout << ">> ";
		cin >> Delete_All_Crew;

		if (Delete_All_Crew == 1)
		{
			Crew_List.clear();
			Temp_Crew_ID = 0;
			cout << "-------------------- All Employee's are Deleted! --------------------" << endl;
		}
		else if(Delete_All_Crew == 2)
		{
			cout << "-------------------- Good Idea! --------------------" << endl;
		}

}


// True or False function that determines if Pilot is available or not
bool Crew_Collections::Pilots_Available_Counter()
{
	bool Checker;

	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{

		if(Crew_Iter -> second.Get_Status() == "Available")
		{
			Checker = true;
		}
		else if(Crew_Iter -> second.Get_Status() != "Available")
		{
			Checker = false;
		}
	}

	return Checker;
}

// Function that prints the AVAILABLE pilots
void Crew_Collections::Print_Pilots_Available()
{
	
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		
		if(Crew_Iter -> second.Get_Type() == "Pilot")
		{

			if(Crew_Iter -> second.Get_Status() == "Available")
			{
				cout << "Employee ID: " << Crew_Iter -> second.Get_ID_Number() << "   Name: " << Crew_Iter -> second.Get_Name()
					 << "   Type: " << Crew_Iter -> second.Get_Type() << "   Status: " << Crew_Iter -> second.Get_Status() << endl;
			}

		}
		
	}
	
}


// True or False function that determines if CoPilot is available or not
bool Crew_Collections::CoPilots_Available_Counter()
{
	bool Checker;

	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{

		if(Crew_Iter -> second.Get_Status() == "Available")
		{
			Checker = true;
		}
		else if(Crew_Iter -> second.Get_Status() != "Available")
		{
			Checker = false;
		}
	}

	return Checker;
	
}

// Function that prints the AVAILABLE CoPilots
void Crew_Collections::Print_CoPilots_Available()
{
	
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
	
		if(Crew_Iter -> second.Get_Type() == "Co-Pilot")
		{
			if(Crew_Iter -> second.Get_Status() == "Available")
			{
				cout << "Employee ID: " << Crew_Iter -> second.Get_ID_Number() << "   Name: " << Crew_Iter -> second.Get_Name()
					 << "   Type: " << Crew_Iter -> second.Get_Type() << "   Status: " << Crew_Iter -> second.Get_Status() << endl;
			}

		}
		
	}
	
}


// True or False function that determines if Crew is available or not
bool Crew_Collections::Crew_Available_Counter()
{
	bool Checker;

	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{

		if(Crew_Iter -> second.Get_Status() == "Available")
		{
			Checker = true;
		}
		else if(Crew_Iter -> second.Get_Status() != "Available")
		{
			Checker = false;
		}
	}

	return Checker;
	
}

// Function that prints the AVAILABLE Crew
void Crew_Collections::Print_Crew_Available()
{
	
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
	
		if(Crew_Iter -> second.Get_Type() == "Cabin")
		{

			if(Crew_Iter -> second.Get_Status() == "Available")
			{
				cout << "Employee ID: " << Crew_Iter -> second.Get_ID_Number() << "   Name: " << Crew_Iter -> second.Get_Name()
					 << "   Type: " << Crew_Iter -> second.Get_Type() << "   Status: " << Crew_Iter -> second.Get_Status() << endl;
			}
				
		}
		
	}
	
}

// Function that updates the availabilty of the Crew members
void Crew_Collections::Update_Availabilty(int Num)
{
	int Availability_Changed;

	for(int i = 0; i < Crew_List.size(); i++)
	{
		if(Crew_List.at(i).Get_ID_Number() == Num)
		{
			if(Crew_List.at(i).Get_Status() == "Available")
			{
				Availability_Changed = 2;
				Crew_List.at(i).Set_Status(Availability_Changed);
			}
		}		
	}		
}

// Revert Availiabilty from busy to AVAILABLE
void Crew_Collections::Revert_Availabilty(int Num)
{
	int Availability_Changed;

	for(int i = 0; i < Crew_List.size(); i++)
	{
		if(Crew_List.at(i).Get_ID_Number() == Num)
		{
			if(Crew_List.at(i).Get_Status() == "On-Leave")
			{
				Availability_Changed = 1;
				Crew_List.at(i).Set_Status(Availability_Changed);
			}
		}		
	}		
}

// FUNCTION NOT APPLICABLE
bool Crew_Collections::Search_Available(int Num)
{
	bool Checker;

		for(int i = 0; i < Crew_List.size(); i++)
		{

			if(Crew_List.count(Num) == 1)
			{
				Checker = true;
			}
			else
			{
				Checker = false;
			}
		}

		return Checker;
}

// Function that prints all the crew members of the map iterator
void Crew_Collections::Print_List()
{
	
	system("@cls||clear");
	cout << "=========================================================================================================" << endl;
	
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		
		cout << "Employee ID: " << Crew_Iter -> second.Get_ID_Number() << "   Name: " << Crew_Iter -> second.Get_Name()
			 << "   Type: " << Crew_Iter -> second.Get_Type() << "   Status: " << Crew_Iter -> second.Get_Status() << endl;
	
	}	

}

// Function that prints a single crew member based on the ID number given by the user
void Crew_Collections::Print_Single()
{

	system("@cls||clear");
	cout << "=========================================================================================================" << endl;
	
	cout << "-------------------- Employee ID's --------------------" << endl;
	for (Crew_Iter = Crew_List.begin(); Crew_Iter != Crew_List.end(); Crew_Iter++)
	{
		cout << "Employee's ID Number: " << Crew_Iter-> second.Get_ID_Number() << endl;
	}
	
	
	cout << "=========================================================================================================" << endl;
	int ID;

	cout << "Please Enter the ID Plane Number you would like to see" << endl;
	cout << ">> ";
	cin >> ID;
	
	if(Crew_List.count(ID) == 1)
	{
		cout << "Employee ID: " << Crew_List.at(ID).Get_ID_Number() << "   Name: " << Crew_List.at(ID).Get_Name() 
			 << "   Type: " << Crew_List.at(ID).Get_Type() << "   Status: " << Crew_List.at(ID).Get_Status() << endl;
	
	}
	else
	{
		cout << "Sorry, Our database does not contain that Employee's ID Number" << endl;
	}	
	
}






















