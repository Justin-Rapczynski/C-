#ifndef CREW_COLLECTIONS_H
#define CREW_COLLECTIONS_H

// Class Declarations 
#include <string>
#include <vector>
#include <map>

// Header File
#include "Crew.h"

using namespace std;

// Class Flights, with private variables and public functions
class Crew_Collections
{
	private:
		map <int, Crew> Crew_List;

	public:
		
		Crew_Collections();
        ~Crew_Collections();
		
		void Add();
		void Edit();
		void Delete();
		void Delete_All();

		bool Pilots_Available_Counter();
		void Print_Pilots_Available();

		bool CoPilots_Available_Counter();
		void Print_CoPilots_Available();

		bool Crew_Available_Counter();
		void Print_Crew_Available();


		void Update_Availabilty(int Num);
		void Revert_Availabilty(int Num);
		bool Search_Available(int Num);
		
		void Print_List();
		void Print_Single();

};




#endif