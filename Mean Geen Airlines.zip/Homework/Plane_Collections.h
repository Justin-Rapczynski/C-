#ifndef PLANE_COLLECTIONS_H
#define PLANE_COLLECTIONS_H

// Class Declarations 
#include <string>
#include <vector>
#include <map>

// Header File
#include "Plane.h"

using namespace std;

// Class Flights, with private variables and public functions
class Plane_Collections
{
	private:
		map <int, Plane> Plane_List;

	public:
		
		Plane_Collections();
		~Plane_Collections();
		
		void Add();
		void Edit();
		void Delete();
		void Delete_All();

		bool Planes_Available_Counter();
		void Print_Planes_Available();

		void Print_Planes_Out();
		void Print_Planes_Repair();
		bool Search_Available(int Num);
		void Update_Plane_Availabilty(int Num);
		void Revert_Plane_Availabilty(int Num);
		void Print_Available_Seats(int Num);
		void Seats_Available(int Num);
		void Print_List();
		void Print_Single();

};

#endif