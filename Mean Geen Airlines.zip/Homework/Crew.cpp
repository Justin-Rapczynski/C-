// Class Declarations
#include <iostream>
#include <string>

// Header Files
#include "Crew.h"

using namespace std;

// Default Constructor with Default values
Crew::Crew()
{
    Name = "No Name";
    ID_Number = 0;
    Type = 0;
    Status = 0;

}

// Overloaded Constructor
Crew::Crew(string Name, int ID_Number, int Type, int Status)
{
    this -> Name = Name;
    this -> ID_Number = ID_Number;
    this -> Type = Type;
    this -> Status = Status;
}

//Setters
void Crew::Set_Name(string Name)
{
    this -> Name = Name;
}
void Crew::Set_ID_Number(int ID_Number)
{
    this -> ID_Number = ID_Number;
}
void Crew::Set_Type(int Type)
{
    this -> Type = Type;
}
void Crew::Set_Status(int Status)
{
    this -> Status = Status;
}

//Getters
string Crew::Get_Name() const
{
    return Name;
}
int Crew::Get_ID_Number() const
{
    return ID_Number;
}
string Crew::Get_Type() const
{
    string Crew_Type;

	if(Type == 1)
	{
		Crew_Type = "Pilot";
	}
	else if(Type == 2)
	{
		Crew_Type = "Co-Pilot";		
	}
	else if(Type == 3)
	{
		Crew_Type = "Cabin";
	}

	return Crew_Type;

}
string Crew::Get_Status() const
{
    string Crew_Satus;

	if(Status == 1)
	{
		Crew_Satus = "Available";
	}
	else if(Status == 2)
	{
		Crew_Satus = "On-Leave";		
	}
	else if(Status == 3)
	{
		Crew_Satus = "Sick";
	}

	return Crew_Satus;
    
}