#ifndef PLANE_H
#define PLANE_H

// Class Declarations
#include <string>

using namespace std;

// Class Flights, with private variables and public functions
class Plane
{
	private:
		int Plane_ID;
		string Make;
		string Model;
		string Tail_Number;
		int Seats;
		int Range;
		int Status;
		
	public:
		Plane();
		Plane(int Plane_ID, string Make, string Model, string Tail_Number, int Seats, int Range, int Status);
		
		//Setters
		void Set_Plane_ID(int Plane_ID);
		void Set_Make(string Make);
		void Set_Model(string Model);
		void Set_Tail_Number(string Tail_Number);
		void Set_Seats(int Seats);
		void Set_Range(int Range);
		void Set_Status(int Status);
		
		// Getters
		int Get_Plane_ID() const;
		string Get_Make() const;
		string Get_Model() const;
		string Get_Tail_Number() const;
		int Get_Seats() const;
		int Get_Range() const;
		string Get_Status() const;


};

#endif